const express = require("express");

const app = express();

app.get("/", function(request, response){
  response.send("<h1>Hello,world!");
});

app.get("/contact", function(request, response){
  response.send("send my contact details");
});
app.get("/about", function(request, response){
  response.send("about me!");
});




app.listen(3000, function(){

console.log("server started on port 3000");

});
